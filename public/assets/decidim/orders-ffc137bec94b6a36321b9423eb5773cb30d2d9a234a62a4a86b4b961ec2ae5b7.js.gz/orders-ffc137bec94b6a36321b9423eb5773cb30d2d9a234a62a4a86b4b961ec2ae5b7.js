// This is left for backwards compatibility. The actual functionality has been
// moved to results_listing.js.es6.
//
// = results_listing

"use strict";

if (window.console) {
  // eslint-disable-next-line no-console
  console.log("decidim/orders.js is deprecated, please use decidim/results_listing.js instead.");
};
